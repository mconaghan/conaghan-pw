<?php
/**
 * @version		$Id: pagination.php 10707 2008-08-21 09:52:47Z eddieajau $
 * @package		Joomla.Framework
 * @subpackage	HTML
 * @copyright	Copyright (C) 2005 - 2008 Open Source Matters. All rights reserved.
 * @license		GNU/GPL, see LICENSE.php
 * Joomla! is free software. This version may have been modified pursuant
 * to the GNU General Public License, and as distributed it includes or
 * is derivative of works licensed under the GNU General Public License or
 * other free or open source software licenses.
 * See COPYRIGHT.php for copyright notices and details.
 */

// Check to ensure this file is within the rest of the framework
defined('JPATH_BASE') or die();

	function pagination_list_footer($list)
	{
		// Initialize variables
		$html = "<div class=\"list-footer\">\n";

		$html .= "\n<div class=\"limit\">".JText::_('Display Num').$list['limitfield']."</div>";
		$html .= $list['pageslinks'];
		$html .= "\n<div class=\"counter\">".$list['pagescounter']."</div>";

		$html .= "\n<input type=\"hidden\" name=\"limitstart\" value=\"".$list['limitstart']."\" />";
		$html .= "\n</div>";

		return $html;
	}

	function pagination_list_render($list)
	{
		// Initialize variables
		$html = null;

		// Reverse output rendering for right-to-left display
		$html .= '';
		$html .= $list['start']['data'];
		$html .= ' &nbsp;';
		$html .= $list['previous']['data'].' &nbsp;';
		foreach( $list['pages'] as $page ) {
			$html .= ' '.$page['data'].' &nbsp;';
		}
		$html .= ' '. $list['next']['data'].' &nbsp;';
		$html .= ' '. $list['end']['data'].' &nbsp;';
		$html .= '';

		return $html;
	}

	function pagination_item_active(&$item)
	{
		global $mainframe;
		if ($mainframe->isAdmin())
		{
			if($item->base>0)
				return "<a title=\"".$item->text."\" onclick=\"javascript: document.adminForm.limitstart.value=".$item->base."; submitform();return false;\">".$item->text."</a>";
			else
				return "<a title=\"".$item->text."\" onclick=\"javascript: document.adminForm.limitstart.value=0; submitform();return false;\">".$item->text."</a>";
		} else {
			return "<a title=\"".$item->text."\" href=\"".$item->link."\" class=\"pagenav active_pagenav\">".$item->text."</a>";
		}
	}

	function pagination_item_inactive(&$item)
	{
		global $mainframe;
		if ($mainframe->isAdmin()) {
			return "<span>".$item->text."</span>";
		} else {
			return "<span class=\"pagenav inactive_pagenav\">".$item->text."</span>";
		}
	}

