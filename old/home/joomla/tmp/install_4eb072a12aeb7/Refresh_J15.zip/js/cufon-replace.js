Cufon.replace('#suckernav > ul > li > a, .contentheading,.componentheading,a.contentpagetitle,.blog_more strong', {textShadow: '1px 1px #777'},{hover:false });
Cufon.replace('h1,div.catItemHeader h3.catItemTitle,h3', {color: '#222'}); 
Cufon.replace('div.right h3,span.latestItemDateCreated', {color:'#fff'}); 
Cufon.replace('h2 ', {color: '-linear-gradient(#666666, #000000)',textShadow: '2px 2px #C0C0C0',hover: {textShadow: '2px 2px #C0C0C0',color: '-linear-gradient(#99CC00, #000000)'}});
Cufon.replace('#logo a', {textShadow: '2px 2px #555',hover: {textShadow: '2px 2px #777',color: '#f0f0f0'}});






