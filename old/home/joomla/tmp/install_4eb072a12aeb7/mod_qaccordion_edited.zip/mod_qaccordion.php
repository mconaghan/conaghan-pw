<?php 

/* Qlue Accordion
*  Copyright (C) 2010 Qlue
*
*  This file is part of Qlue Accordion.
*
*  Qlue Accordion is free software: you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  Qlue Accordion is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with Qlue Accordion. If not, see <http://www.gnu.org/licenses/>.
*/

//no direct access
defined("_JEXEC") or die("Restricted Access");

// Include the syndicate functions only once
require_once( dirname(__FILE__).DS.'helper.php' );

// Get Module Css
$document = &JFactory::getDocument();
$document->addStyleSheet( "modules/mod_qaccordion/style/qaccordion.css" );

// variable to pass articles to the Layout
$articles = Qlue::accordion($params);

// load the mootool function which makes this module work
Qlue::MooTools($params);

// Require the Layout 
require( JModuleHelper::getLayoutPath( 'mod_qaccordion' ) );

?>