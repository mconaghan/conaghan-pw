<?php

/* Qlue Accordion
*  Copyright (C) 2010 Qlue
*
*  This file is part of Qlue Accordion.
*
*  Qlue Accordion is free software: you can redistribute it and/or modify
*  it under the terms of the GNU General Public License as published by
*  the Free Software Foundation, either version 3 of the License, or
*  (at your option) any later version.
*
*  Qlue Accordion is distributed in the hope that it will be useful,
*  but WITHOUT ANY WARRANTY; without even the implied warranty of
*  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*  GNU General Public License for more details.
*
*  You should have received a copy of the GNU General Public License
*  along with Qlue Accordion. If not, see <http://www.gnu.org/licenses/>.
*/

//no direct access
defined("_JEXEC") or die("Restricted Access");

//get the helper route file from com_content for later use
require_once( JPATH_SITE .DS. 'components' .DS. 'com_content' .DS. 'helpers' .DS. 'route.php' ); 

class Qlue {
	
	function accordion($params){
		
        //connect to the database object
        $db     = &JFactory::getDBO();
		//get the user object and find what access level the user has
		$user   = &JFactory::getUser();
		$access = $user->aid;
        
		//get the parameters
		$count  = $params->get("countItem", 5);
		$catId  = $params->get("categoryId", null);
		$order  = $params->get("orderBy", "article");
		
		//prepare the order sql query
		switch($order){			
			case "article":
			    $order = "ordering ASC";
			break;			
			case "alpha":
			    $order = "title ASC";
			break;			
			case "modified":
			    $order = "modified ASC";
			break;			
			case "newDate":
			    $order = "created ASC";
			break;			
			case "oldDate":
			    $order = "created DESC";
			break;			
		}		
        
		//build the sql query, Searches all articles which are in the specified category and is published. Will only bring back the articles the user is allowed to see. Example guests will not see registered content
		$query = "SELECT * FROM #__content WHERE ".
		         "catid ='". (int)$catId ."' AND state ='1' ".
				 "AND access <= ". (int)$access .
				 " ORDER BY ". $order;
        
		//set the query and return the entered amount of results
		$db->setQuery($query, 0, (int)$count);
		
		//put the results into the variable $articles
		$articles = $db->loadObjectList();		
        
		//return the variable to prepare for display
		return $articles;

	}
	
	function renderContent( $content ){
		
		global $mainframe;
		
		//set the introduction text of the article ready to convert content
		$content->text = $content->introtext;
		
		// import all content plugins
		JPluginHelper::importPlugin('content');
		
		// get list of avaliable plugins
		$dispatcher =& JDispatcher::getInstance();
		
		//set the parameters ready for converting content
		$plgParams = new JParameter('');
		
		// process the content through all content plugins
		$results = $dispatcher->trigger( 'onPrepareContent', array (&$content, &$plgParams, 0) );
		
		return $content->text;
		
	}
	
	function readMore( $id, $catid, $sectionid, $title, $access, $params ){
		
		//get the user object
		$user     = JFactory::getUser();
		
		//get the parameter to see if read more is set to yes or no
		$readMore = $params->get("readMore", 0) ? true : false;
		
		//if read more is set to no stop the function
		if(!$readMore){
			return;
		}
		
		//check to see if the user has access to the full article, if not redirect to login/ register page
		if( $access <= $user->aid ){
			$link = JRoute::_( ContentHelperRoute::getArticleRoute( (int)$id, (int)$catid, (int)$sectionid ) );
		} else {
			//link to the com_user login page
			$link = JRoute::_( 'index.php?option=com_user&view=login' );
		}
		
		//generate the read more link
		$readMoreLink = '<a class="readon" title="'. $title .'" href="'. $link .'" >Read More </a>';
		
		//return the read more link
		return $readMoreLink;

	}

	function MooTools($params){
		
		//include the mootools framework incase it not already loaded
		JHTML::_('behavior.mootools');
        
		//get the parameters
		$arrayId    = $params->get( "arrayId", 0 );
		$alwaysHide = $params->get( "alwaysHide", 0 ) ? 'true' : 'false';
		$opacity    = $params->get( "opacity", 0 ) ? 'true' : 'false';
		$hover      = $params->get( "hover", 0 );
        $baseurl    = JURI::root(true) ."/modules/mod_qaccordion";
		
		//if On Hover is set to on in the parameters add the roll over code into the accordion script
		if( $hover ){
			$rollover = "$$('#qaccordion h3').addEvent('mouseenter', function() { this.fireEvent('click'); });";
		} else {
			$rollover = '';
		}
        
		//get the document object
		$document = &JFactory::getDocument();
		
		//create the mootools script which makes the module work
        $document->addCustomTag( "<script type='text/javascript'>".
						         "window.addEvent('domready', function(){".
								 $rollover .
                                 "new Accordion('#qaccordion .tabber', '#qaccordion .content', {".
									 "display: ". (int)$arrayId .",".
                                     "alwaysHide: ". $alwaysHide .",".
								     "opacity: ". $opacity .",".
								     "onActive: function(toggler, element){".
								     "toggler.setStyle('background', 'url(". $baseurl ."/images/arrow2.png) no-repeat right -2px');".
						         "},".
						         "onBackground: function(toggler, element){".
								     "toggler.setStyle('background', 'url(". $baseurl ."/images/arrow1.png) no-repeat right -2px');".
						         "}})".
						         "});".
						         "</script>");
	}

}

?>